# Testes v13.06

Executados:

- `node --check core.js`
- `node --check app.js`
- `node --test tests/core.test.js`
- Validação de parser monetário brasileiro e máscara de centavos.
- Validação de patrimônio bruto/líquido, cartão, pagamento, transferência e iFood em dinheiro.
- Validação de migração de backup v13.
- Validação de rendimento automático descontando entrada real no Giro.
- Validação do corte de uma base atualizada no mesmo dia, sem soma dupla.
- Validação da remoção de bases duplicadas no mesmo dia.
- Validação de lançamento retroativo entre bases sem classificação falsa como CDI.
- Validação dos rendimentos separados de Futuro/Giro e automático/manual.
- Validação dos arquivos referenciados pelo manifest e service worker.
- Manifest, ícones, cache e service worker atualizados para v13.06.
