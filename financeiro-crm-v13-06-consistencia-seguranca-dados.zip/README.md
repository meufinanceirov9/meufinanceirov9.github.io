# Financeiro CRM v13.06

Build: `2026-07-21-v13-06-consistencia-e-seguranca-dos-dados`

Versão local estável baseada na v13.05. Preserva o padrão visual aprovado da linha v13 e reforça consistência das bases diárias, classificação de rendimentos e recuperação de dados.

## Melhorias da v13.06

- Corrige atualização do patrimônio no mesmo dia:
  - a nova conferência atualiza o horário de corte da base;
  - movimentos já absorvidos pelo saldo real não são somados novamente;
  - movimentos posteriores continuam atualizando o saldo vivo.
- Remove duplicidades antigas de patrimônio no mesmo dia ao migrar ou importar backup, conservando a conferência mais recente.
- Considera lançamentos retroativos de dias intermediários na auditoria entre bases, evitando que entradas esquecidas sejam classificadas como CDI.
- Corrige a auditoria do Dashboard: rendimento já informado passa a ser tratado como classificado, sem alerta falso de pendência.
- Separa os rendimentos de Caixinha Futuro e Caixinha Giro:
  - total de cada caixinha no mês;
  - origem automática nas bases e origem manual;
  - histórico unificado dos dois tipos.
- Adiciona recuperação automática das dez alterações mais recentes e ação para desfazer a última alteração.
- Valida o conteúdo e mostra a quantidade de registros antes de substituir os dados por um backup importado.
- O logotipo RS abre o Perfil; a escolha entre modo Usuário e Desenvolvedor fica explícita nessa tela.
- Mostra `Olá, [nome]` no Dashboard quando o nome estiver configurado.
- Atualiza cache, manifest, service worker e ícones para v13.06.

## Regras preservadas

- Rendimento aumenta patrimônio, mas não entra no faturamento do trabalho.
- Entrada lançada em Giro/Futuro é descontada antes da sugestão de CDI.
- Existe no máximo uma base real por dia.
- Todos os dados continuam locais e podem ser exportados em JSON ou CSV.

## Publicação

Suba todos os arquivos desta pasta na raiz do GitHub Pages. Depois acesse:

`https://SEU_USUARIO.github.io/?v=1306`
