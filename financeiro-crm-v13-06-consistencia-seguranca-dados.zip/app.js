(function(){
  'use strict';
  const C = window.FinanceiroCore;
  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

  let state = loadState();
  let currentView = 'dashboard';
  let toastTimer = null;
  const AUTO_BACKUP_LIMIT = 10;

  function loadState(){
    try{
      const raw = localStorage.getItem(C.STORAGE_KEY);
      if(!raw) return C.defaultState();
      return C.migrateState(JSON.parse(raw));
    }catch(err){
      console.warn('Falha ao carregar estado local. Criando estado zerado.', err);
      return C.defaultState();
    }
  }
  function saveState(){
    state.updatedAt = C.nowISO();
    state.settings.appVersion = C.APP_VERSION;
    state.settings.buildId = C.BUILD_ID;
    try{
      localStorage.setItem(C.STORAGE_KEY, JSON.stringify(state));
      return true;
    }catch(err){
      console.error('Falha ao salvar dados locais.', err);
      notify('Não foi possível salvar. Baixe um backup antes de continuar.', 'warn');
      return false;
    }
  }
  function getAutoBackups(){
    const prefix = `${C.STORAGE_KEY}-backup-`;
    const backups = [];
    try{
      for(let index=0; index<localStorage.length; index+=1){
        const key = localStorage.key(index);
        if(!key || !key.startsWith(prefix)) continue;
        try{
          const parsed = JSON.parse(localStorage.getItem(key));
          const data = parsed && parsed.data && parsed.data.settings ? parsed.data : parsed;
          if(!data || typeof data !== 'object' || !data.settings) continue;
          const keyTime = Number(key.split('-').pop());
          backups.push({
            key,
            label:String((parsed && parsed.label) || 'alteração'),
            savedAt:(parsed && parsed.savedAt) || (Number.isFinite(keyTime) ? new Date(keyTime).toISOString() : ''),
            data
          });
        }catch(_){ }
      }
    }catch(_){ }
    return backups.sort((a,b)=>C.timestampMs(b.savedAt)-C.timestampMs(a.savedAt));
  }
  function pruneAutoBackups(){
    getAutoBackups().slice(AUTO_BACKUP_LIMIT).forEach(item => {
      try{ localStorage.removeItem(item.key); }catch(_){ }
    });
  }
  function backupBefore(label){
    try{
      const savedAt = C.nowISO();
      const payload = {savedAt, label, appVersion:C.APP_VERSION, data:state};
      localStorage.setItem(`${C.STORAGE_KEY}-backup-${label}-${Date.now()}`, JSON.stringify(payload));
      pruneAutoBackups();
    }catch(_){ }
  }
  function notify(message, type='info'){
    const el = $('#toast');
    if(!el) return;
    el.textContent = message;
    el.className = `toast show ${type}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(()=> el.classList.remove('show'), 3600);
  }
  function escapeHtml(str){
    return String(str ?? '').replace(/[&<>"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
  }
  function privateMoney(value){ return state.settings.hideBalances ? 'R$ •••••' : C.formatCurrencyBR(value); }
  function privatePercent(value, digits=2){ return state.settings.hideBalances ? '•••' : `${Number(value || 0).toFixed(digits)}%`; }
  function privateBarWidth(value){ return state.settings.hideBalances ? 0 : Math.min(100, Math.max(0, value || 0)); }
  function fieldValue(form, name){ return (form.elements[name] && form.elements[name].value) || ''; }
  function moneyValue(form, name){ return C.parseCurrencyBR(fieldValue(form,name)); }
  function accountOptions(selected){
    return C.ASSET_ACCOUNTS.map(k => `<option value="${k}" ${selected===k?'selected':''}>${C.ACCOUNT_LABELS[k]}</option>`).join('');
  }
  function movementTypeLabel(type){
    return ({
      entrada:'Entrada', saida:'Saída', transferencia:'Transferência', rendimento:'Rendimento',
      ifood_dinheiro:'iFood dinheiro', cartao:'Compra no cartão', pagamento_cartao:'Pagamento do cartão'
    })[type] || type;
  }
  function movementTone(type){
    return ({entrada:'good', rendimento:'good', ifood_dinheiro:'good', saida:'bad', cartao:'bad', transferencia:'neutral', pagamento_cartao:'neutral'})[type] || 'neutral';
  }
  function movementAmountText(m){
    const x = C.normalizeMovement(m);
    if(x.type === 'ifood_dinheiro') return privateMoney(x.received - x.change);
    if(x.type === 'transferencia') return privateMoney(x.value);
    if(x.type === 'pagamento_cartao') return privateMoney(x.value);
    return privateMoney(x.value);
  }
  function accountTitle(key){ return C.ACCOUNT_LABELS[key] || key; }
  function setRuntimeIcon(){
    const href = `favicon-v13-06.png?v=1306-${encodeURIComponent(C.BUILD_ID)}`;
    let link = document.querySelector('link[data-runtime-favicon]') || document.querySelector('link[rel="icon"]');
    if(!link){ link = document.createElement('link'); document.head.appendChild(link); }
    link.setAttribute('rel','icon');
    link.setAttribute('type','image/png');
    link.setAttribute('sizes','192x192');
    link.setAttribute('href', href);
    link.setAttribute('data-runtime-favicon','true');
  }
  async function refreshAppCache(){
    backupBefore('antes-atualizar-cache');
    notify('Limpando cache do app e recarregando...', 'info');
    try{
      if('caches' in window){
        const keys = await caches.keys();
        await Promise.all(keys.filter(k => k.startsWith('financeiro-crm')).map(k => caches.delete(k)));
      }
      if('serviceWorker' in navigator){
        const regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map(r => r.unregister()));
      }
    }catch(err){ console.warn('Falha ao limpar cache automaticamente.', err); }
    const cleanPath = window.location.pathname || '/';
    window.location.replace(`${cleanPath}?v=1306-${Date.now()}`);
  }

  function render(){
    const root = $('#app');
    if(!root) return;
    root.innerHTML = `
      <aside class="sidebar">
        <div class="brand-row">
          <button class="brand-icon" data-view="perfil" title="Abrir perfil">RS</button>
          <div><strong>Financeiro CRM</strong><small>${C.APP_VERSION} • modo local</small></div>
        </div>
        <nav class="nav-list">
          ${navItem('dashboard','Início','🏠')}
          ${navItem('registrar','Registrar','➕')}
          ${navItem('historico','Histórico','📜')}
          ${navItem('rendimentos','Rendimentos','🌱')}
          ${navItem('perfil','Perfil','👤')}
        </nav>
        <div class="sidebar-footer">
          <span>Backup local ativo</span>
          <button class="link-btn" data-action="exportBackup">Baixar backup</button>
        </div>
      </aside>
      <main class="main">
        <header class="topbar">
          <button class="mobile-menu" data-action="toggleMenu">☰</button>
          <div><h1>${escapeHtml(viewTitle())}</h1><p>${viewSubtitle()}</p></div>
          <div class="top-actions">
            <button class="ghost-btn" data-action="toggleBalances">${state.settings.hideBalances?'Mostrar':'Ocultar'} saldos</button>
            <button class="primary-btn compact" data-action="quickPatrimonio">+ Patrimônio</button>
          </div>
        </header>
        <section class="content">${renderView()}</section>
      </main>
      <div id="modal" class="modal" aria-hidden="true"></div>
      <div id="toast" class="toast"></div>
    `;
  }
  function navItem(view,label,icon){ return `<button class="nav-item ${currentView===view?'active':''}" data-view="${view}"><span>${icon}</span>${label}</button>`; }
  function viewTitle(){
    if(currentView === 'dashboard' && state.settings.ownerName) return `Olá, ${state.settings.ownerName}`;
    return ({dashboard:'Dashboard', registrar:'Registrar', historico:'Histórico', rendimentos:'Rendimentos', perfil:'Perfil e backups'})[currentView] || 'Dashboard';
  }
  function viewSubtitle(){
    return ({
      dashboard:'Patrimônio, objetivo, progresso e ritmo necessário.',
      registrar:'Cadastre patrimônio completo, entradas, saídas, cartão, rendimento e iFood em dinheiro.',
      historico:'Todos os registros locais, com edição e exclusão.',
      rendimentos:'Acompanhe o CDI separado por Caixinha Futuro e Caixinha Giro, com ajuda automática pela diferença diária.',
      perfil:'Modo local, backup, importação e configurações.'
    })[currentView] || '';
  }
  function renderView(){
    if(currentView === 'registrar') return renderRegistrar();
    if(currentView === 'historico') return renderHistorico();
    if(currentView === 'rendimentos') return renderRendimentos();
    if(currentView === 'perfil') return renderPerfil();
    return renderDashboard();
  }

  function renderDashboard(){
    const balances = C.calculateBalances(state);
    const goal = C.calculateGoal(state);
    const month = C.getMonthlySummary(state);
    const progressWidth = privateBarWidth(goal.progress);
    const snapText = balances.snapshot ? `Base: ${C.formatDateBR(balances.snapshot.data)}` : 'Sem patrimônio base ainda';
    const dueText = goal.overdue ? 'Prazo vencido' : goal.dueToday ? 'Prazo hoje' : `${goal.days} dia(s) restantes`;
    const composition = C.ASSET_ACCOUNTS.map(k => {
      const value = balances.assets[k] || 0;
      const pct = balances.bruto > 0 ? Math.max(0, value / balances.bruto * 100) : 0;
      return `<div class="composition-row"><div><b>${accountTitle(k)}</b><small>${privateMoney(value)}</small></div><div class="bar"><span style="width:${privateBarWidth(pct)}%"></span></div><em>${privatePercent(pct,1)}</em></div>`;
    }).join('');
    return `
      <div class="hero-grid">
        <section class="card hero-card">
          <div class="card-title"><div><span class="eyebrow">Prioridade</span><h2>Patrimônio e objetivo</h2><p>Clique no valor da meta ou na data para editar direto no Dashboard.</p></div></div>
          <div class="metric-grid">
            <div class="metric big"><span>Patrimônio líquido</span><strong class="sensitive">${privateMoney(balances.liquido)}</strong><small>${snapText}</small></div>
            <div class="metric big"><span>Falta para <button class="inline-edit" data-action="editGoalTarget">${privateMoney(goal.goal.target)}</button></span><strong class="sensitive">${privateMoney(goal.falta)}</strong><small>Prazo: <button class="inline-edit" data-action="editGoalDue">${C.formatDateBR(goal.goal.due)}</button> • ${dueText}</small></div>
          </div>
          <div class="progress-wrap"><div class="progress-info"><b>${privatePercent(goal.progress,2)} concluído</b><span>Ritmo necessário: ${privateMoney(goal.monthlyRequired)} / mês</span></div><div class="progress-bar"><span style="width:${progressWidth}%"></span></div></div>
          <div class="quick-row"><button class="primary-btn" data-action="quickPatrimonio">Registrar patrimônio completo</button><button class="ghost-btn" data-view="registrar">Novo lançamento</button><button class="ghost-btn" data-action="exportBackup">Baixar backup</button></div>
        </section>
        <section class="card status-card">
          <div class="card-title"><div><span class="eyebrow">Mês atual</span><h2>Resumo de movimentos</h2></div></div>
          <div class="mini-stats">
            <div><span>Entradas</span><b class="positive">${privateMoney(month.income)}</b></div>
            <div><span>Saídas/cartão</span><b class="negative">${privateMoney(month.expense)}</b></div>
            <div><span>Rendimentos</span><b>${privateMoney(month.yield)}</b></div>
            <div><span>Saldo do trabalho</span><b>${privateMoney(month.netWork)}</b></div>
          </div>
          <div class="logic-note"><b>Regra:</b> rendimento aumenta patrimônio, mas não entra como faturamento de trabalho.</div>
        </section>
      </div>
      ${renderBalanceAudit(balances)}
      <div class="grid two">
        <section class="card"><div class="card-title"><div><span class="eyebrow">Composição</span><h2>Onde está o patrimônio</h2></div><button class="ghost-btn compact" data-action="quickPatrimonio">Atualizar base</button></div>${composition}<div class="debt-line"><span>Fatura aberta</span><b>${privateMoney(balances.faturaAberta)}</b></div><div class="debt-line"><span>Outras dívidas</span><b>${privateMoney(balances.outrasDividas)}</b></div></section>
        <section class="card"><div class="card-title"><div><span class="eyebrow">Últimos registros</span><h2>Histórico recente</h2></div><button class="ghost-btn compact" data-view="historico">Ver tudo</button></div>${renderRecentHistory()}</section>
      </div>
      ${state.settings.devMode ? renderDevPanel() : ''}
    `;
  }
  function renderBalanceAudit(balances){
    const details = C.snapshotDeltaDetails(state);
    if(!details) return '';
    const suggested = details.suggestedYield || {futuro:0,giro:0,total:0};
    const recordedFuturo = C.round2(details.current.rendimentoFuturo || 0);
    const recordedGiro = C.round2(details.current.rendimentoGiro || 0);
    const recordedYield = C.round2(recordedFuturo + recordedGiro);
    const pendingYield = {
      futuro:C.round2(Math.max(0, suggested.futuro - recordedFuturo)),
      giro:C.round2(Math.max(0, suggested.giro - recordedGiro))
    };
    pendingYield.total = C.round2(pendingYield.futuro + pendingYield.giro);
    const unclassified = C.round2(details.unexplained - recordedYield);
    const hasPendingYield = pendingYield.total >= 0.01;
    const hasUnexplained = Math.abs(unclassified) >= 0.01;
    const hasPostSnapshotMovements = balances.applied && balances.applied.length > 0;
    if(!hasUnexplained && !hasPostSnapshotMovements && !hasPendingYield) return '';
    const deltas = details.accountDeltas.length
      ? details.accountDeltas.map(x => `${escapeHtml(x.label)} ${x.delta>=0?'+':''}${privateMoney(x.delta)}`).join(' • ')
      : 'Sem variação por conta.';
    const movementText = hasPostSnapshotMovements
      ? `${balances.applied.length} lançamento(s) depois da última base já estão sendo somados ao saldo vivo.`
      : 'Nenhum lançamento depois da última base.';
    const tone = hasUnexplained ? 'warn' : 'good';
    const yieldText = hasPendingYield
      ? `<div class="logic-note good"><b>Provável CDI ainda não classificado:</b> Futuro ${privateMoney(pendingYield.futuro)} • Giro ${privateMoney(pendingYield.giro)} • Total ${privateMoney(pendingYield.total)}. <button class="link-btn" data-action="applyLatestYieldSuggestion">Aplicar na última base</button></div>`
      : recordedYield >= 0.01
        ? `<div class="logic-note good"><b>Rendimento já classificado:</b> Futuro ${privateMoney(recordedFuturo)} • Giro ${privateMoney(recordedGiro)}.</div>`
        : '';
    return `<section class="card audit-card"><div class="card-title"><div><span class="eyebrow">Conferência</span><h2>Patrimônio auditado</h2><p>O app compara a última base com a anterior, desconta lançamentos e separa o que parece CDI/rendimento.</p></div><span class="pill ${tone}">${hasUnexplained?'Revisar':'OK'}</span></div><div class="mini-stats"><div><span>Variação entre bases</span><b>${privateMoney(details.delta)}</b></div><div><span>Explicado por lançamentos</span><b>${privateMoney(details.explained)}</b></div><div><span>Rendimento classificado</span><b>${privateMoney(recordedYield)}</b></div><div><span>Ainda sem classificação</span><b>${privateMoney(unclassified)}</b></div></div><div class="logic-note ${tone}"><b>Leitura:</b> ${deltas}. ${movementText} ${hasUnexplained?'A diferença restante ainda precisa ser rendimento, entrada, saída ou ajuste de base.':''}</div>${yieldText}</section>`;
  }
  function renderRecentHistory(){
    const items = combinedHistory().slice(0,6);
    if(!items.length) return `<div class="empty">Nenhum registro ainda. Comece pelo patrimônio completo.</div>`;
    return `<div class="list">${items.map(renderHistoryItem).join('')}</div>`;
  }
  function renderDevPanel(){
    const validation = C.validateState(state);
    const diff = C.explainSnapshotDifference(state);
    return `<section class="card dev-card"><div class="card-title"><div><span class="eyebrow">Modo desenvolvedor</span><h2>Auditoria local</h2><p>Esse painel só aparece no modo dev.</p></div><span class="pill">${C.BUILD_ID}</span></div><div class="mini-stats"><div><span>Validação</span><b>${validation.ok?'OK':'Atenção'}</b></div><div><span>Patrimônios</span><b>${state.patrimonio.length}</b></div><div><span>Movimentos</span><b>${state.movements.length}</b></div><div><span>Storage</span><b>${C.STORAGE_KEY}</b></div></div>${validation.ok?'<div class="logic-note good">Nenhum problema estrutural encontrado.</div>':`<div class="logic-note warn">${validation.problems.map(escapeHtml).join('<br>')}</div>`}${diff?`<div class="logic-note"><b>Diferença entre últimos patrimônios:</b> ${privateMoney(diff.delta)} • explicado por movimentos: ${privateMoney(diff.explained)} • sem explicação: ${privateMoney(diff.unexplained)}</div>`:''}</section>`;
  }

  function renderRegistrar(){
    const balances = C.calculateBalances(state);
    return `
      <div class="grid two">
        <section class="card accent"><div class="card-title"><div><span class="eyebrow">Base real</span><h2>Patrimônio completo</h2><p>Use quando for conferir os saldos reais. Isso vira a nova base de cálculo do app.</p></div></div>${patrimonioForm()}</section>
        <section class="card"><div class="card-title"><div><span class="eyebrow">Movimento</span><h2>Novo lançamento</h2><p>Entradas, saídas, transferências, cartão, rendimento e iFood em dinheiro.</p></div></div>${movementForm()}</section>
      </div>
      <section class="card"><div class="card-title"><div><span class="eyebrow">Saldo vivo agora</span><h2>Antes de lançar</h2></div></div><div class="account-grid">${C.ASSET_ACCOUNTS.map(k=>`<div class="account-card"><span>${accountTitle(k)}</span><b>${privateMoney(balances.assets[k])}</b></div>`).join('')}<div class="account-card debt"><span>Fatura aberta</span><b>${privateMoney(balances.faturaAberta)}</b></div></div></section>
    `;
  }
  function buildPatrimonioDraftFromValues(values, item){
    return C.normalizeSnapshot({
      id: (item && item.id) || values.id || C.id('pat_preview'),
      createdAt: (item && item.createdAt) || values.createdAt || C.nowISO(),
      capturedAt: (item && C.snapshotCapturedAt(item)) || values.capturedAt || C.nowISO(),
      updatedAt: C.nowISO(),
      data: values.data || C.todayISO(),
      futuro: values.futuro, giro: values.giro, carteira: values.carteira, banco: values.banco, investimentos: values.investimentos,
      faturaAberta: values.faturaAberta, outrasDividas: values.outrasDividas,
      rendimentoFuturo: values.rendimentoFuturo || 0, rendimentoGiro: values.rendimentoGiro || 0,
      observacoes: values.observacoes || ''
    });
  }
  function draftFromPatrimonioForm(form){
    const existing = form.dataset.id ? state.patrimonio.find(p=>p.id===form.dataset.id) : null;
    return buildPatrimonioDraftFromValues({
      id: form.dataset.id || '',
      createdAt: existing?.createdAt || C.nowISO(),
      capturedAt: existing ? C.snapshotCapturedAt(existing) : C.nowISO(),
      data: fieldValue(form,'data'),
      futuro: moneyValue(form,'futuro'), giro: moneyValue(form,'giro'), carteira: moneyValue(form,'carteira'), banco: moneyValue(form,'banco'), investimentos: moneyValue(form,'investimentos'),
      faturaAberta: moneyValue(form,'faturaAberta'), outrasDividas: moneyValue(form,'outrasDividas'),
      rendimentoFuturo: moneyValue(form,'rendimentoFuturo'), rendimentoGiro: moneyValue(form,'rendimentoGiro'),
      observacoes: fieldValue(form,'observacoes')
    });
  }
  function renderYieldAssist(estimate, current){
    if(!estimate || !estimate.ok) return `<div class="logic-note"><b>Rendimento automático:</b> salve pelo menos uma base anterior para o app conseguir comparar um dia com o outro.</div>`;
    const suggested = estimate.suggested || {futuro:0,giro:0,total:0};
    const diffLines = estimate.assetDiffs
      .filter(x => Math.abs(x.diff) >= 0.01)
      .map(x => `${escapeHtml(x.label)}: real ${privateMoney(x.actual)} • esperado ${privateMoney(x.expected)} • diferença ${x.diff>=0?'+':''}${privateMoney(x.diff)}`)
      .join('<br>') || 'Nenhuma diferença relevante.';
    const movementCount = estimate.movements.length;
    const tone = suggested.total >= 0.01 ? 'good' : 'neutral';
    const button = suggested.total >= 0.01 ? `<button class="ghost-btn compact" type="button" data-action="applyYieldSuggestion">Usar sugestão</button>` : '';
    return `<div class="logic-note ${tone}" data-role="yield-suggestion"><b>Ajuda do rendimento:</b> comparando com ${C.formatDateBR(estimate.previous.data)}, descontando ${movementCount} lançamento(s), o app sugere CDI de <b>Futuro ${privateMoney(suggested.futuro)}</b> e <b>Giro ${privateMoney(suggested.giro)}</b>. ${button}<br><small>${diffLines}</small></div>`;
  }
  function applyYieldSuggestionToForm(form){
    const draft = draftFromPatrimonioForm(form);
    const estimate = C.estimateSnapshotYields(state, draft, {excludeId: form.dataset.id || draft.id, currentCapturedAt: draft.capturedAt});
    if(!estimate || !estimate.ok) return notify('Ainda não existe base anterior para calcular rendimento.', 'warn');
    form.elements.rendimentoFuturo.value = C.currencyInput(estimate.suggested.futuro);
    form.elements.rendimentoGiro.value = C.currencyInput(estimate.suggested.giro);
    const box = $('[data-role="yield-suggestion"]', form);
    if(box) box.outerHTML = renderYieldAssist(estimate, draft);
    notify('Sugestão de rendimento aplicada nos campos da base.', 'success');
  }
  function refreshYieldSuggestionBox(form){
    const box = $('[data-role="yield-suggestion"]', form);
    if(!box) return;
    const draft = draftFromPatrimonioForm(form);
    const estimate = C.estimateSnapshotYields(state, draft, {excludeId: form.dataset.id || draft.id, currentCapturedAt: draft.capturedAt});
    box.outerHTML = renderYieldAssist(estimate, draft);
  }

  function patrimonioForm(item){
    const balancesNow = C.calculateBalances(state);
    const captureNow = C.nowISO();
    const baseValues = item ? C.normalizeSnapshot(item) : Object.assign({data:C.todayISO(), createdAt:captureNow, capturedAt:captureNow}, balancesNow.assets, {faturaAberta:balancesNow.faturaAberta, outrasDividas:balancesNow.outrasDividas, rendimentoFuturo:0, rendimentoGiro:0, observacoes:''});
    const preview = buildPatrimonioDraftFromValues(baseValues, item || null);
    const estimate = C.estimateSnapshotYields(state, preview, {excludeId:item?item.id:preview.id, currentCapturedAt:preview.capturedAt});
    const p = C.normalizeSnapshot(Object.assign({}, baseValues, (!item && estimate && estimate.ok && estimate.suggested.total >= 0.01) ? {rendimentoFuturo:estimate.suggested.futuro, rendimentoGiro:estimate.suggested.giro} : {}));
    return `<form class="form" data-form="patrimonio" data-id="${item?escapeHtml(p.id):''}">
      <div class="form-grid">
        <label>Data<input type="date" name="data" value="${p.data}" required></label>
        <label>Caixinha Futuro<input class="money-field" name="futuro" inputmode="decimal" value="${C.currencyInput(p.futuro)}" placeholder="0,00"></label>
        <label>Caixinha Giro<input class="money-field" name="giro" inputmode="decimal" value="${C.currencyInput(p.giro)}" placeholder="0,00"></label>
        <label>Carteira / espécie<input class="money-field" name="carteira" inputmode="decimal" value="${C.currencyInput(p.carteira)}" placeholder="0,00"></label>
        <label>Banco / conta<input class="money-field" name="banco" inputmode="decimal" value="${C.currencyInput(p.banco)}" placeholder="0,00"></label>
        <label>Outros investimentos<input class="money-field" name="investimentos" inputmode="decimal" value="${C.currencyInput(p.investimentos)}" placeholder="0,00"></label>
        <label>Fatura aberta<input class="money-field" name="faturaAberta" inputmode="decimal" value="${C.currencyInput(p.faturaAberta)}" placeholder="0,00"></label>
        <label>Outras dívidas<input class="money-field" name="outrasDividas" inputmode="decimal" value="${C.currencyInput(p.outrasDividas)}" placeholder="0,00"></label>
        <label>Rendimento Futuro calculado<input class="money-field" name="rendimentoFuturo" inputmode="decimal" value="${C.currencyInput(p.rendimentoFuturo)}" placeholder="0,00"></label>
        <label>Rendimento Giro calculado<input class="money-field" name="rendimentoGiro" inputmode="decimal" value="${C.currencyInput(p.rendimentoGiro)}" placeholder="0,00"></label>
      </div>
      ${renderYieldAssist(estimate, p)}
      <label>Observação<input name="observacoes" value="${escapeHtml(p.observacoes)}" placeholder="Conferência do dia"></label>
      <div class="form-actions"><button class="primary-btn" type="submit">Salvar patrimônio</button>${item?'<button class="danger-btn" type="button" data-action="deleteSnapshot" data-id="'+escapeHtml(p.id)+'">Excluir</button>':''}</div>
    </form>`;
  }
  function movementForm(item){
    const m = item ? C.normalizeMovement(item) : {id:'', type:'entrada', data:C.todayISO(), description:'', category:'', account:'banco', fromAccount:'giro', toAccount:'carteira', value:0, received:0, change:0, notes:''};
    return `<form class="form" data-form="movement" data-id="${item?escapeHtml(m.id):''}">
      <div class="form-grid">
        <label>Tipo<select name="type" data-role="movement-type">
          ${['entrada','saida','transferencia','rendimento','ifood_dinheiro','cartao','pagamento_cartao'].map(t=>`<option value="${t}" ${m.type===t?'selected':''}>${movementTypeLabel(t)}</option>`).join('')}
        </select></label>
        <label>Data<input type="date" name="data" value="${m.data}" required></label>
        <label>Descrição<input name="description" value="${escapeHtml(m.description || '')}" placeholder="Ex.: salário, entrega, mercado"></label>
        <label>Categoria<input name="category" value="${escapeHtml(m.category || '')}" placeholder="opcional"></label>
      </div>
      <div class="movement-dynamic">${movementDynamicFields(m)}</div>
      <label>Observação<input name="notes" value="${escapeHtml(m.notes || '')}" placeholder="opcional"></label>
      <div class="form-actions"><button class="primary-btn" type="submit">Salvar lançamento</button>${item?'<button class="danger-btn" type="button" data-action="deleteMovement" data-id="'+escapeHtml(m.id)+'">Excluir</button>':''}</div>
    </form>`;
  }
  function movementDynamicFields(m){
    const type = m.type || 'entrada';
    if(type === 'transferencia'){
      return `<div class="form-grid"><label>Conta de origem<select name="fromAccount">${accountOptions(m.fromAccount)}</select></label><label>Conta de destino<select name="toAccount">${accountOptions(m.toAccount)}</select></label><label>Valor<input class="money-field" name="value" inputmode="decimal" value="${C.currencyInput(m.value)}" required></label></div><div class="logic-note">Transferência não conta como faturamento nem despesa. Só muda o dinheiro de lugar.</div>`;
    }
    if(type === 'ifood_dinheiro'){
      return `<div class="form-grid"><label>Recebido do cliente em dinheiro<input class="money-field" name="received" inputmode="decimal" value="${C.currencyInput(m.received)}" required></label><label>Troco usado da Caixinha Giro<input class="money-field" name="change" inputmode="decimal" value="${C.currencyInput(m.change)}"></label></div><div class="logic-note">Carteira aumenta pelo valor recebido. Giro diminui pelo troco. O patrimônio líquido sobe apenas pelo líquido da corrida.</div>`;
    }
    if(type === 'cartao'){
      return `<div class="form-grid"><label>Valor da compra<input class="money-field" name="value" inputmode="decimal" value="${C.currencyInput(m.value)}" required></label></div><div class="logic-note">Compra no cartão aumenta a fatura aberta e reduz o patrimônio líquido, mesmo sem sair dinheiro da conta agora.</div>`;
    }
    if(type === 'pagamento_cartao'){
      return `<div class="form-grid"><label>Conta usada para pagar<select name="account">${accountOptions(m.account)}</select></label><label>Valor pago<input class="money-field" name="value" inputmode="decimal" value="${C.currencyInput(m.value)}" required></label></div><div class="logic-note">Pagamento do cartão reduz uma conta e reduz a fatura. O líquido não deve mudar por isso.</div>`;
    }
    const label = type === 'rendimento' ? 'Conta que rendeu' : 'Conta afetada';
    const note = type === 'rendimento' ? 'Rendimento aumenta patrimônio, mas fica separado do faturamento.' : type === 'saida' ? 'Saída reduz diretamente a conta escolhida.' : 'Entrada aumenta a conta escolhida e entra como faturamento/receita.';
    return `<div class="form-grid"><label>${label}<select name="account">${accountOptions(m.account)}</select></label><label>Valor<input class="money-field" name="value" inputmode="decimal" value="${C.currencyInput(m.value)}" required></label></div><div class="logic-note">${note}</div>`;
  }

  function renderHistorico(){
    const items = combinedHistory();
    return `<section class="card"><div class="card-title"><div><span class="eyebrow">Registros locais</span><h2>Histórico completo</h2><p>Clique em editar para ajustar qualquer registro.</p></div><button class="ghost-btn" data-action="exportCSV">Exportar CSV</button></div>${items.length?`<div class="list history-list">${items.map(renderHistoryItem).join('')}</div>`:'<div class="empty">Nenhum registro ainda.</div>'}</section>`;
  }
  function combinedHistory(){
    const pats = state.patrimonio.map(p => ({kind:'snapshot', data:p.data, createdAt:p.createdAt, item:C.normalizeSnapshot(p)}));
    const movs = state.movements.map(m => ({kind:'movement', data:m.data, createdAt:m.createdAt, item:C.normalizeMovement(m)}));
    return pats.concat(movs).sort((a,b)=> C.sortDesc(a,b));
  }
  function renderHistoryItem(entry){
    if(entry.kind === 'snapshot'){
      const p = entry.item;
      const sums = C.snapshotAssets(p);
      return `<article class="list-item"><div class="item-main"><span class="tag neutral">Patrimônio</span><b>${C.formatDateBR(p.data)}</b><small>${escapeHtml(p.observacoes || 'Base diária completa')}</small></div><div class="item-side"><strong>${privateMoney(sums.liquido)}</strong><button class="link-btn" data-action="editSnapshot" data-id="${escapeHtml(p.id)}">Editar</button></div></article>`;
    }
    const m = entry.item;
    const impact = C.movementImpact(m);
    const subtitle = m.type === 'transferencia' ? `${accountTitle(m.fromAccount)} → ${accountTitle(m.toAccount)}` : m.type === 'ifood_dinheiro' ? `Recebido ${privateMoney(m.received)} • troco ${privateMoney(m.change)}` : m.type === 'cartao' ? 'Aumenta fatura aberta' : m.type === 'pagamento_cartao' ? `Pago por ${accountTitle(m.account)}` : accountTitle(m.account);
    return `<article class="list-item"><div class="item-main"><span class="tag ${movementTone(m.type)}">${movementTypeLabel(m.type)}</span><b>${escapeHtml(m.description || C.defaultMovementDescription(m.type))}</b><small>${C.formatDateBR(m.data)} • ${escapeHtml(subtitle)}</small></div><div class="item-side"><strong class="${impact.net<0?'negative':impact.net>0?'positive':''}">${movementAmountText(m)}</strong><button class="link-btn" data-action="editMovement" data-id="${escapeHtml(m.id)}">Editar</button></div></article>`;
  }

  function getAllTimeCaixinhaYields(){
    const totals = {futuro:0, giro:0, manual:0, snapshot:0, total:0};
    state.patrimonio.map(C.normalizeSnapshot).forEach(p => {
      totals.futuro = C.round2(totals.futuro + p.rendimentoFuturo);
      totals.giro = C.round2(totals.giro + p.rendimentoGiro);
      totals.snapshot = C.round2(totals.snapshot + p.rendimentoFuturo + p.rendimentoGiro);
    });
    state.movements.map(C.normalizeMovement).filter(m=>m.type==='rendimento' && ['futuro','giro'].includes(m.account)).forEach(m => {
      totals[m.account] = C.round2(totals[m.account] + m.value);
      totals.manual = C.round2(totals.manual + m.value);
    });
    totals.total = C.round2(totals.futuro + totals.giro);
    return totals;
  }
  function caixinhaYieldHistory(){
    const items = state.movements
      .map(C.normalizeMovement)
      .filter(m=>m.type==='rendimento' && ['futuro','giro'].includes(m.account))
      .map(m=>({kind:'movement', item:m, data:m.data, createdAt:m.createdAt}));
    state.patrimonio.map(C.normalizeSnapshot).forEach(p => {
      if(p.rendimentoFuturo >= 0.01) items.push({kind:'snapshot-yield', account:'futuro', value:p.rendimentoFuturo, data:p.data, createdAt:p.capturedAt, item:p});
      if(p.rendimentoGiro >= 0.01) items.push({kind:'snapshot-yield', account:'giro', value:p.rendimentoGiro, data:p.data, createdAt:p.capturedAt, item:p});
    });
    return items.sort(C.sortDesc);
  }
  function renderYieldHistoryItem(entry){
    if(entry.kind === 'movement') return renderHistoryItem(entry);
    return `<article class="list-item"><div class="item-main"><span class="tag good">Automático</span><b>${escapeHtml(accountTitle(entry.account))}</b><small>${C.formatDateBR(entry.data)} • classificado na base diária</small></div><div class="item-side"><strong class="positive">${privateMoney(entry.value)}</strong><button class="link-btn" data-action="editSnapshot" data-id="${escapeHtml(entry.item.id)}">Ver base</button></div></article>`;
  }
  function renderRendimentos(){
    const balances = C.calculateBalances(state);
    const month = C.getYieldSummary(state);
    const allTime = getAllTimeCaixinhaYields();
    const history = caixinhaYieldHistory();
    const monthCaixinhas = C.round2(month.futuro.total + month.giro.total);
    const monthSnapshot = C.round2(month.futuro.snapshot + month.giro.snapshot);
    const monthManual = C.round2(month.futuro.manual + month.giro.manual);
    return `<div class="grid two"><section class="card"><div class="card-title"><div><span class="eyebrow">Rendimentos</span><h2>Caixinhas separadas</h2><p>O CDI de Futuro e Giro agora é mostrado separadamente, sem entrar no faturamento do trabalho.</p></div></div><div class="mini-stats"><div><span>Futuro agora</span><b>${privateMoney(balances.assets.futuro)}</b></div><div><span>Giro agora</span><b>${privateMoney(balances.assets.giro)}</b></div><div><span>Futuro no mês</span><b>${privateMoney(month.futuro.total)}</b></div><div><span>Giro no mês</span><b>${privateMoney(month.giro.total)}</b></div><div><span>Total no mês</span><b>${privateMoney(monthCaixinhas)}</b></div><div><span>Total registrado</span><b>${privateMoney(allTime.total)}</b></div></div><div class="logic-note"><b>Composição do mês:</b> ${privateMoney(monthSnapshot)} detectado nas bases + ${privateMoney(monthManual)} lançado manualmente.</div><form class="form" data-form="quick-yield"><div class="form-grid"><label>Data<input type="date" name="data" value="${C.todayISO()}"></label><label>Caixinha<select name="account"><option value="futuro">Caixinha Futuro</option><option value="giro">Caixinha Giro</option></select></label><label>Valor<input class="money-field" name="value" inputmode="decimal" placeholder="0,00"></label></div><button class="primary-btn" type="submit">Salvar rendimento</button></form></section><section class="card"><div class="card-title"><div><span class="eyebrow">Histórico</span><h2>Rendimentos registrados</h2><p>Inclui os valores automáticos das bases e os lançamentos manuais.</p></div></div>${history.length?`<div class="list history-list">${history.slice(0,30).map(renderYieldHistoryItem).join('')}</div>`:'<div class="empty">Nenhum rendimento registrado ainda.</div>'}</section></div>`;
  }

  function renderPerfil(){
    const lastBackup = state.settings.lastBackupAt ? new Date(state.settings.lastBackupAt).toLocaleString('pt-BR') : 'Nunca';
    const autoBackups = getAutoBackups();
    const latestAuto = autoBackups[0];
    const latestAutoText = latestAuto && C.timestampMs(latestAuto.savedAt) ? new Date(latestAuto.savedAt).toLocaleString('pt-BR') : 'Nenhum ponto criado ainda';
    return `<div class="grid two">
      <section class="card"><div class="card-title"><div><span class="eyebrow">Perfil</span><h2>Modo local estável</h2><p>Na linha v13 local, login e nuvem ficam bloqueados para proteger a base local.</p></div><span class="pill good">Local</span></div><form class="form" data-form="settings"><div class="form-grid"><label>Seu nome no app<input name="ownerName" value="${escapeHtml(state.settings.ownerName || '')}" placeholder="Renan"></label><label>Cartão fecha dia<input type="number" min="1" max="28" name="cardCloseDay" value="${state.settings.cardCloseDay}"></label><label>Cartão vence dia<input type="number" min="1" max="28" name="cardDueDay" value="${state.settings.cardDueDay}"></label></div><button class="primary-btn" type="submit">Salvar configurações</button></form><div class="logic-note"><b>Modo do aplicativo:</b> use o modo Usuário no dia a dia; o modo Desenvolvedor apenas revela diagnóstico e limpeza de cache.</div><div class="quick-row"><button class="${state.settings.devMode?'ghost-btn':'primary-btn'}" data-action="setUserMode">Usuário</button><button class="${state.settings.devMode?'primary-btn':'ghost-btn'}" data-action="setDevMode">Desenvolvedor</button></div></section>
      <section class="card"><div class="card-title"><div><span class="eyebrow">Segurança</span><h2>Backup e restauração</h2><p>Último backup baixado: ${escapeHtml(lastBackup)}</p></div></div><div class="quick-row stack"><button class="primary-btn" data-action="exportBackup">Baixar backup JSON</button><button class="ghost-btn" data-action="exportCSV">Exportar CSV</button><label class="file-btn">Importar backup JSON<input type="file" accept="application/json,.json" data-action="importBackupFile"></label><button class="danger-btn" data-action="resetApp">Zerar app local</button></div><div class="logic-note good"><b>Recuperação automática:</b> o app guarda até ${AUTO_BACKUP_LIMIT} pontos antes de alterações importantes.<br><small>Último ponto: ${escapeHtml(latestAutoText)}</small><div class="quick-row"><button class="ghost-btn compact" data-action="restoreLatestBackup" ${latestAuto?'':'disabled'}>Desfazer última alteração</button></div></div></section>
      ${state.settings.devMode ? '<section class="card"><div class="card-title"><div><span class="eyebrow">Ferramenta dev</span><h2>Cache e atualização</h2><p>Ferramenta temporária para desenvolvimento local. Não aparece no modo usuário.</p></div><span class="pill">v13.06</span></div><div class="quick-row stack"><button class="ghost-btn" data-action="refreshApp">Atualizar app e limpar cache</button></div><div class="logic-note"><b>Produto final:</b> em versão pública/nuvem, isso fica oculto por ambiente/admin.</div></section>' : ''}
      <section class="card full"><div class="card-title"><div><span class="eyebrow">Objetivo principal</span><h2>Meta e prazo</h2></div></div><form class="form" data-form="goal"><div class="form-grid"><label>Nome<input name="name" value="${escapeHtml(state.settings.goal.name)}"></label><label>Valor da meta<input class="money-field" name="target" inputmode="decimal" value="${C.currencyInput(state.settings.goal.target)}"></label><label>Data final<input type="date" name="due" value="${state.settings.goal.due}"></label></div><button class="primary-btn" type="submit">Salvar objetivo</button></form></section>
    </div>`;
  }

  function openModal(html){
    const modal = $('#modal');
    modal.innerHTML = `<div class="modal-backdrop" data-action="closeModal"></div><div class="modal-card"><button class="modal-close" data-action="closeModal">×</button>${html}</div>`;
    modal.classList.add('show');
    modal.setAttribute('aria-hidden','false');
  }
  function closeModal(){ const modal=$('#modal'); if(modal){ modal.classList.remove('show'); modal.setAttribute('aria-hidden','true'); modal.innerHTML=''; } }

  function editGoalTarget(){
    const current = C.currencyInput(state.settings.goal.target) || '100.000,00';
    openModal(`<div class="card-title"><div><h2>Editar valor da meta</h2><p>Todos os campos de valor usam máscara igual: os centavos sobem enquanto você digita. Para R$ 100.000,00, digite 10000000 ou cole 100.000,00.</p></div></div><form class="form" data-form="goal-target"><label>Valor do objetivo<input class="money-field" name="target" inputmode="decimal" value="${escapeHtml(current)}" autofocus></label><button class="primary-btn" type="submit">Salvar</button></form>`);
    setTimeout(()=> $('[name="target"]', $('#modal'))?.focus(), 60);
  }
  function editGoalDue(){
    openModal(`<div class="card-title"><div><h2>Editar prazo da meta</h2><p>Ao mudar a data, o ritmo mensal necessário recalcula automaticamente.</p></div></div><form class="form" data-form="goal-due"><label>Data final<input type="date" name="due" value="${state.settings.goal.due}" autofocus></label><button class="primary-btn" type="submit">Salvar</button></form>`);
  }
  function quickPatrimonio(){ openModal(`<div class="card-title"><div><h2>Registrar patrimônio completo</h2><p>Essa base substitui os saldos estimados pelo saldo real do dia.</p></div></div>${patrimonioForm()}`); }
  function editSnapshot(id){ const item = state.patrimonio.find(p=>p.id===id); if(item) openModal(`<div class="card-title"><div><h2>Editar patrimônio</h2><p>Ajuste a base real salva.</p></div></div>${patrimonioForm(item)}`); }
  function editMovement(id){ const item = state.movements.find(m=>m.id===id); if(item) openModal(`<div class="card-title"><div><h2>Editar lançamento</h2><p>Ajuste o movimento salvo.</p></div></div>${movementForm(item)}`); }

  function savePatrimonioForm(form){
    const existing = form.dataset.id ? state.patrimonio.find(p=>p.id===form.dataset.id) : null;
    const captureNow = C.nowISO();
    const item = C.normalizeSnapshot({
      id: form.dataset.id || C.id('pat'),
      createdAt: existing?.createdAt || captureNow,
      updatedAt: captureNow,
      capturedAt: existing ? C.snapshotCapturedAt(existing) : captureNow,
      data: fieldValue(form,'data'),
      futuro: moneyValue(form,'futuro'), giro: moneyValue(form,'giro'), carteira: moneyValue(form,'carteira'), banco: moneyValue(form,'banco'), investimentos: moneyValue(form,'investimentos'),
      faturaAberta: moneyValue(form,'faturaAberta'), outrasDividas: moneyValue(form,'outrasDividas'), rendimentoFuturo: moneyValue(form,'rendimentoFuturo'), rendimentoGiro: moneyValue(form,'rendimentoGiro'),
      observacoes: fieldValue(form,'observacoes')
    });
    if(!C.isValidDate(item.data)) return notify('Informe uma data válida.', 'warn');
    backupBefore('salvar-patrimonio');
    const idx = state.patrimonio.findIndex(p=>p.id===item.id);
    if(idx >= 0){
      state.patrimonio[idx] = item;
    } else {
      const sameDayIdx = state.patrimonio.findIndex(p => C.normalizeSnapshot(p).data === item.data);
      if(sameDayIdx >= 0){
        item.id = state.patrimonio[sameDayIdx].id;
        item.createdAt = state.patrimonio[sameDayIdx].createdAt || item.createdAt;
        state.patrimonio[sameDayIdx] = item;
      } else {
        state.patrimonio.push(item);
      }
    }
    state.patrimonio.sort(C.sortByDateThenCreated);
    saveState(); closeModal(); currentView='dashboard'; render(); notify('Patrimônio salvo, rendimento conferido e cálculos atualizados.', 'success');
  }
  function saveMovementForm(form){
    const type = fieldValue(form,'type') || 'entrada';
    const old = state.movements.find(m=>m.id===form.dataset.id);
    const item = C.normalizeMovement({
      id: form.dataset.id || C.id('mov'),
      createdAt: old?.createdAt || C.nowISO(),
      updatedAt: C.nowISO(),
      type,
      data: fieldValue(form,'data'),
      description: fieldValue(form,'description') || C.defaultMovementDescription(type),
      category: fieldValue(form,'category'),
      account: fieldValue(form,'account'),
      fromAccount: fieldValue(form,'fromAccount'),
      toAccount: fieldValue(form,'toAccount'),
      value: moneyValue(form,'value'),
      received: moneyValue(form,'received'),
      change: moneyValue(form,'change'),
      notes: fieldValue(form,'notes')
    });
    if(!C.isValidDate(item.data)) return notify('Informe uma data válida.', 'warn');
    if(type === 'ifood_dinheiro' && item.received <= 0) return notify('Informe o valor recebido em dinheiro.', 'warn');
    if(type === 'ifood_dinheiro' && item.change > item.received) return notify('O troco não pode ser maior que o valor recebido.', 'warn');
    if(type !== 'ifood_dinheiro' && item.value <= 0) return notify('Informe um valor maior que zero.', 'warn');
    if(type === 'transferencia' && item.fromAccount === item.toAccount) return notify('Origem e destino precisam ser diferentes.', 'warn');
    backupBefore('salvar-movimento');
    const idx = state.movements.findIndex(m=>m.id===item.id);
    if(idx >= 0) state.movements[idx] = item; else state.movements.push(item);
    state.movements.sort(C.sortByDateThenCreated);
    saveState(); closeModal(); render(); notify('Lançamento salvo e saldos recalculados.', 'success');
  }
  function saveSettings(form){
    backupBefore('salvar-configuracoes');
    state.settings.ownerName = fieldValue(form,'ownerName').trim();
    state.settings.cardCloseDay = C.clamp(parseInt(fieldValue(form,'cardCloseDay'),10)||4,1,28);
    state.settings.cardDueDay = C.clamp(parseInt(fieldValue(form,'cardDueDay'),10)||11,1,28);
    saveState(); render(); notify('Configurações salvas.', 'success');
  }
  function saveGoal(form){
    const current = state.settings.goal || C.defaultState().settings.goal;
    const hasName = !!form.elements.name;
    const hasTarget = !!form.elements.target;
    const hasDue = !!form.elements.due;
    const goal = C.normalizeGoal({
      id: current.id || 'goal_main',
      name: hasName ? (fieldValue(form,'name') || current.name || 'Objetivo principal') : current.name,
      target: hasTarget ? moneyValue(form,'target') : current.target,
      due: hasDue ? fieldValue(form,'due') : current.due
    });
    if(goal.target <= 0) return notify('O valor do objetivo precisa ser maior que zero.', 'warn');
    if(!C.isValidDate(goal.due)) return notify('Informe uma data final válida.', 'warn');
    backupBefore('salvar-objetivo');
    state.settings.goal = goal; saveState(); closeModal(); render(); notify('Objetivo atualizado. Cálculos recalculados.', 'success');
  }
  function saveQuickYield(form){
    const item = C.normalizeMovement({type:'rendimento', data: fieldValue(form,'data'), account: fieldValue(form,'account'), value: moneyValue(form,'value'), description: `Rendimento ${accountTitle(fieldValue(form,'account'))}`});
    if(item.value <= 0) return notify('Informe o rendimento.', 'warn');
    backupBefore('salvar-rendimento');
    state.movements.push(item); state.movements.sort(C.sortByDateThenCreated); saveState(); render(); notify('Rendimento salvo separado do faturamento.', 'success');
  }
  function applyLatestYieldSuggestion(){
    const details = C.snapshotDeltaDetails(state);
    if(!details || !details.current || !details.suggestedYield || details.suggestedYield.total < 0.01) return notify('Não há rendimento provável para aplicar na última base.', 'warn');
    const idx = state.patrimonio.findIndex(p => p.id === details.current.id);
    if(idx < 0) return notify('Não encontrei a última base para atualizar.', 'warn');
    backupBefore('aplicar-rendimento-sugerido');
    const current = C.normalizeSnapshot(state.patrimonio[idx]);
    current.rendimentoFuturo = details.suggestedYield.futuro;
    current.rendimentoGiro = details.suggestedYield.giro;
    current.updatedAt = C.nowISO();
    state.patrimonio[idx] = current;
    saveState(); render(); notify('Rendimento provável aplicado na última base.', 'success');
  }

  function deleteSnapshot(id){
    if(!confirm('Excluir este patrimônio?')) return;
    backupBefore('excluir-patrimonio');
    state.patrimonio = state.patrimonio.filter(p=>p.id!==id); saveState(); closeModal(); render(); notify('Patrimônio excluído.', 'success');
  }
  function deleteMovement(id){
    if(!confirm('Excluir este lançamento?')) return;
    backupBefore('excluir-movimento');
    state.movements = state.movements.filter(m=>m.id!==id); saveState(); closeModal(); render(); notify('Lançamento excluído.', 'success');
  }
  function exportBackup(){
    state.settings.lastBackupAt = C.nowISO(); saveState();
    const payload = {exportedAt:C.nowISO(), appVersion:C.APP_VERSION, buildId:C.BUILD_ID, storageKey:C.STORAGE_KEY, data:state};
    downloadFile(JSON.stringify(payload,null,2), `${C.BACKUP_PREFIX}-${C.todayISO()}-${C.APP_VERSION}.json`, 'application/json');
    render(); notify('Backup JSON baixado.', 'success');
  }
  function exportCSV(){
    const rows = [[
      'registro','data','tipo','descricao','categoria','conta','conta_origem','conta_destino',
      'valor','recebido','troco','futuro','giro','carteira','banco','investimentos',
      'fatura_aberta','outras_dividas','rendimento_futuro','rendimento_giro','patrimonio_bruto','patrimonio_liquido','observacao'
    ]];
    state.patrimonio.map(C.normalizeSnapshot).forEach(p=>{
      const sums = C.snapshotAssets(p);
      rows.push([
        'patrimonio', p.data, 'Patrimônio completo', 'Base real diária', '', '', '', '',
        '', '', '', p.futuro, p.giro, p.carteira, p.banco, p.investimentos,
        p.faturaAberta, p.outrasDividas, p.rendimentoFuturo, p.rendimentoGiro, sums.bruto, sums.liquido, p.observacoes
      ]);
    });
    state.movements.map(C.normalizeMovement).forEach(m=>rows.push([
      'movimento', m.data, movementTypeLabel(m.type), m.description, m.category, m.account || '', m.fromAccount || '', m.toAccount || '',
      m.value, m.received, m.change, '', '', '', '', '', '', '', '', '', '', '', m.notes
    ]));
    const csv = '\ufeff' + rows.map(row => row.map(cell => `"${String(cell ?? '').replace(/"/g,'""')}"`).join(';')).join('\n');
    downloadFile(csv, `financeiro-crm-${C.todayISO()}-${C.APP_VERSION}.csv`, 'text/csv;charset=utf-8');
    notify('CSV completo exportado.', 'success');
  }
  function downloadFile(content, filename, type){
    const blob = new Blob([content], {type});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }
  async function importBackupFile(file){
    if(!file) return;
    try{
      if(file.size > 10 * 1024 * 1024) return notify('Esse backup é maior que 10 MB e não será importado.', 'warn');
      const text = await file.text();
      const parsed = JSON.parse(text);
      const source = parsed && parsed.data && parsed.data.settings ? parsed.data : parsed;
      const recognized = source && typeof source === 'object' && source.settings && (Array.isArray(source.patrimonio) || Array.isArray(source.movements) || Array.isArray(source.lancamentos));
      if(!recognized) return notify('Esse JSON não parece ser um backup do Financeiro CRM.', 'warn');
      const imported = C.migrateState(source);
      const validation = C.validateState(imported);
      if(!validation.ok) return notify(`Backup recusado: ${validation.problems[0] || 'há dados inválidos.'}`, 'warn');
      const confirmation = `Importar ${imported.patrimonio.length} patrimônio(s) e ${imported.movements.length} lançamento(s)? Os dados atuais serão substituídos, mas ficarão disponíveis na recuperação automática.`;
      if(!confirm(confirmation)) return notify('Importação cancelada.', 'info');
      backupBefore('antes-importar');
      state = imported;
      saveState(); currentView='dashboard'; render(); notify('Backup importado com sucesso.', 'success');
    }catch(err){ console.error(err); notify('Não consegui importar esse JSON.', 'warn'); }
  }
  function restoreLatestBackup(){
    const latest = getAutoBackups()[0];
    if(!latest) return notify('Ainda não existe um ponto de recuperação.', 'warn');
    const when = C.timestampMs(latest.savedAt) ? new Date(latest.savedAt).toLocaleString('pt-BR') : 'o último ponto';
    if(!confirm(`Desfazer a última alteração e restaurar os dados de ${when}?`)) return;
    const restored = C.migrateState(latest.data);
    const validation = C.validateState(restored);
    if(!validation.ok) return notify('O ponto de recuperação está inconsistente e não foi restaurado.', 'warn');
    backupBefore('antes-restaurar');
    state = restored;
    saveState(); currentView='dashboard'; render(); notify('Última alteração desfeita com segurança.', 'success');
  }
  function resetApp(){
    if(!confirm('Zerar todos os dados locais?')) return;
    backupBefore('antes-zerar');
    state = C.defaultState(); saveState(); currentView='dashboard'; render(); notify('App zerado neste aparelho.', 'success');
  }

  document.addEventListener('click', (ev)=>{
    const viewBtn = ev.target.closest('[data-view]');
    if(viewBtn){ currentView = viewBtn.dataset.view; document.body.classList.remove('menu-open'); render(); return; }
    const btn = ev.target.closest('[data-action]');
    if(!btn) return;
    const action = btn.dataset.action;
    if(action === 'toggleMenu') document.body.classList.toggle('menu-open');
    if(action === 'toggleBalances'){ state.settings.hideBalances = !state.settings.hideBalances; saveState(); render(); }
    if(action === 'toggleDev'){ state.settings.devMode = !state.settings.devMode; saveState(); render(); notify(state.settings.devMode?'Modo desenvolvedor ativo.':'Modo usuário ativo.'); }
    if(action === 'setUserMode'){ state.settings.devMode = false; saveState(); render(); notify('Modo usuário ativo.'); }
    if(action === 'setDevMode'){ state.settings.devMode = true; saveState(); render(); notify('Modo desenvolvedor ativo.'); }
    if(action === 'quickPatrimonio') quickPatrimonio();
    if(action === 'editGoalTarget') editGoalTarget();
    if(action === 'editGoalDue') editGoalDue();
    if(action === 'closeModal') closeModal();
    if(action === 'editSnapshot') editSnapshot(btn.dataset.id);
    if(action === 'editMovement') editMovement(btn.dataset.id);
    if(action === 'deleteSnapshot') deleteSnapshot(btn.dataset.id);
    if(action === 'deleteMovement') deleteMovement(btn.dataset.id);
    if(action === 'exportBackup') exportBackup();
    if(action === 'exportCSV') exportCSV();
    if(action === 'resetApp') resetApp();
    if(action === 'restoreLatestBackup') restoreLatestBackup();
    if(action === 'refreshApp') refreshAppCache();
    if(action === 'applyYieldSuggestion') applyYieldSuggestionToForm(btn.closest('form'));
    if(action === 'applyLatestYieldSuggestion') applyLatestYieldSuggestion();
  });
  function applyMoneyMask(input){
    if(!input) return;
    input.value = C.currencyInputFromCentsDigits(input.value);
    try{ input.setSelectionRange(input.value.length, input.value.length); }catch(_){ }
  }
  function normalizeMoneyField(input){
    if(!input) return;
    input.value = C.normalizeCurrencyInputDisplay(input.value);
  }

  document.addEventListener('focusin', (ev)=>{
    const input = ev.target.closest('input.money-field');
    if(!input) return;
    setTimeout(()=>{ try{ input.select(); }catch(_){ } }, 0);
  });
  document.addEventListener('input', (ev)=>{
    const input = ev.target.closest('input.money-field');
    if(!input) return;
    applyMoneyMask(input);
    const form = input.closest('form[data-form="patrimonio"]');
    if(form && !['rendimentoFuturo','rendimentoGiro'].includes(input.name)) refreshYieldSuggestionBox(form);
  });
  document.addEventListener('focusout', (ev)=>{
    const input = ev.target.closest('input.money-field');
    if(!input) return;
    normalizeMoneyField(input);
  });

  document.addEventListener('submit', (ev)=>{
    const form = ev.target.closest('form[data-form]');
    if(!form) return;
    ev.preventDefault();
    const kind = form.dataset.form;
    if(kind === 'patrimonio') savePatrimonioForm(form);
    if(kind === 'movement') saveMovementForm(form);
    if(kind === 'settings') saveSettings(form);
    if(kind === 'goal' || kind === 'goal-target' || kind === 'goal-due') saveGoal(form);
    if(kind === 'quick-yield') saveQuickYield(form);
  });
  document.addEventListener('change', (ev)=>{
    const typeSelect = ev.target.closest('[data-role="movement-type"]');
    if(typeSelect){
      const form = typeSelect.closest('form');
      const dynamic = $('.movement-dynamic', form);
      const old = {
        type: typeSelect.value,
        account: fieldValue(form,'account') || 'banco',
        fromAccount: fieldValue(form,'fromAccount') || 'giro',
        toAccount: fieldValue(form,'toAccount') || 'carteira',
        value: moneyValue(form,'value'),
        received: moneyValue(form,'received'),
        change: moneyValue(form,'change')
      };
      dynamic.innerHTML = movementDynamicFields(old);
    }
    const patDate = ev.target.closest('form[data-form="patrimonio"] input[name="data"]');
    if(patDate) refreshYieldSuggestionBox(patDate.closest('form'));
    const file = ev.target.matches('[data-action="importBackupFile"]') ? ev.target.files[0] : null;
    if(file) importBackupFile(file);
  });
  document.addEventListener('keydown', (ev)=>{ if(ev.key === 'Escape') closeModal(); });

  window.addEventListener('load', ()=>{
    saveState();
    setRuntimeIcon();
    render();
    if('serviceWorker' in navigator){
      navigator.serviceWorker.register('./service-worker.js?v=1306').then(reg => {
        if(reg && reg.update) reg.update().catch(()=>{});
      }).catch(()=>{});
    }
  });
})();
